﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Ex1
{
    public class Utilities
    {
        public string Greet(string name)
        {
            if (name == null)
            {
                return "Hello, my friend.";
            }

            if (name == name.ToUpper())
            {
                return "HELLO, " + name + "!";
            }

            return "Hello, " + name + ".";
        }

        public List<string> NamesList(string[] names, bool isUpper)
        {
            List<string> newNames = new List<string>();
            for (int i = 0; i < names.Length; i++)
            {
                if (names[i] == names[i].ToUpper() && isUpper)
                    newNames.Add(RemoveSpecialCharacters(names[i]));
                else if (names[i] != names[i].ToUpper() && !isUpper)
                    newNames.Add(RemoveSpecialCharacters(names[i]));
            }

            return newNames;
        }

        private void InitializeWords(bool isUpper, out string and, out string hello, out string sign)
        {
            if (isUpper)
            {
                and = " AND ";
                hello = " HELLO ";
                sign = "!";
            }
            else
            {
                and = " and ";
                hello = "Hello, ";
                sign = ".";
            }
        }

        public string Greeting(List<string> names, bool isUpper)
        {
            string and, hello, sign;
            string greeting = "";
            InitializeWords(isUpper, out and, out hello, out sign);

            if (names.Count == 0 || names == null)
            {
                return greeting;
            }

            else if (names.Count == 1)
            {
                greeting = hello;
                greeting += names[0];
            }

            else
            {
                greeting = hello;
                for (int i = 0; i < names.Count - 1; i++)
                {
                    if (i != names.Count - 2)
                        greeting += names[i] + ", ";
                    else
                        greeting += names[i] + and + names[i + 1];
                }
            }
            return greeting + sign;
        }


        public string Greet(string[] names)
        {
            return Greeting(NamesList(names, false), false) + Greeting(NamesList(names, true), true);
        }

        public string[] CheckForSpecialForm(string[] names)
        {
            string[] copy = new string[names.Length];
            int i = 0;
            foreach (var name in names)
                copy[i++] = RemoveSpecialCharacters(name);
            return copy;
        }

        public static string RemoveSpecialCharacters(string name)
        {
            Regex r = new Regex("(?:[^a-z0-9, ]|(?<=[\"])s)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled);
            return r.Replace(name, String.Empty);
        }

        public string[] SeparatedAtCommas(string[] names)
        {
            List<string> newNames = new List<string>();
            char[] charSeparators = new char[] { ',' };

            for (var i = 0; i < names.Length; i++)
            {
                string[] words = names[i].Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);
                for (var j = 0; j < words.Length; j++)
                {
                    //words[j] = Regex.Replace(words[j], @" ", "");
                    words[j] = words[j].Trim();
                    newNames.Add(words[j]);
                }
            }
            return newNames.ToArray();
        }

        public string Greet(string[] names, bool deleteCommas)
        {
            if (deleteCommas)
                names = SeparatedAtCommas(names);
            return Greeting(NamesList(names, false), false) + Greeting(NamesList(names, true), true);
        }
    }
}
