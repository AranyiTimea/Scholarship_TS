﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Ex1
{
	class Program
	{
		static void Main(string[] args)
		{
			string[] names = new string[] { "Victor", "Elena, Dan" };
			Utilities ut = new Utilities();
			Console.WriteLine(ut.Greet(names));

			string name = "\"George, Dan\"";
            Console.WriteLine(RemoveSpecialCharacters(name));

            string[] newNames = ut.SeparatedAtCommas(names);
			for(int i = 0; i < newNames.Length; i++)
                Console.WriteLine(newNames[i]);

		}

		public static string RemoveSpecialCharacters(string name)
		{
			Regex r = new Regex("(?:[^a-z0-9, ]|(?<=[\"])s)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled);
			return r.Replace(name, String.Empty);
		}
	}
}
