﻿using System;
using Ex1;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestsTDD;

namespace UnitTestsTDD
{
	[TestClass]
	public class UnitTest1
	{
		[TestMethod]
		public void TestMethodGreet()
		{
			//arrange
			Utilities ut = new Utilities();
			string expected = "Hello, Alina.";
			string name = "Alina";

			//act
			string actual = ut.Greet(name);

			//assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestIfStringIsNull()
		{
			//arrange
			Utilities ut = new Utilities();
			string expected = "Hello, my friend.";
			string name = null;

			//act
			string actual = ut.Greet(name);

			//assert
			Assert.AreEqual(expected, actual);
		}


		[TestMethod]
		public void TestShouting()
		{
			//arrange
			Utilities ut = new Utilities();
			string expected = "HELLO, MARIA!";
			string name = "MARIA";

			//act
			string actual = ut.Greet(name);

			//assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestGreetingTwoPeople()
		{
			//arrange
			Utilities ut = new Utilities();
			string expected = "Hello, George and Ioana.";
			string[] names = new string[] { "George", "Ioana" };

			//act
			string actual = ut.Greet(names);

			//assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestGreetingMultiplePeople()
		{
			//arrange
			Utilities ut = new Utilities();
			string expected = "Hello, Marius, Vali and Ana.";
			string[] names = new string[] { "Marius", "Vali", "Ana" };

			//act
			string actual = ut.Greet(names);

			//assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestGreetingAndShoutingToMultiplePeople()
		{
			//arrange
			Utilities ut = new Utilities();
			string expected = "Hello, Ana and George. HELLO MARIA!";
			string[] names = new string[] { "Ana", "MARIA", "George"};

			//act
			string actual = ut.Greet(names);

			//assert
			Assert.AreEqual(expected, actual);
		}

        [TestMethod]
        public void TestCommaSeparated()
        {
            //arrange
            Utilities ut = new Utilities();
            string expected = "Hello, Victor, Elena and Dan.";
            string[] names = new string[] { "Victor", "Elena, Dan" };

            //act
            string actual = ut.Greet(names, true);

            //assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestGreetingSpecialPeople()
        {
            //arrange
            Utilities ut = new Utilities();
            string expected = "Hello, George and George, Dan.";
            string[] names = new string[] { "George", "\"George, Dan\"" };

            //act
            string actual = ut.Greet(names);

            //assert
            Assert.AreEqual(expected, actual);
        }
    }
}
