﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ex1;

namespace UnitTests_Ex1
{
	[TestClass]
	public class UnitTest1
	{
		[TestMethod]
		public void TestMethod1()
		{
			// Arrange
			double expected = 1.5;

			// Act

			// Assert
			double actual = Program.Average(2, 1);
			Assert.AreEqual(expected, actual, 0.001, "The method doesn't calculate the average.");
		}

		[TestMethod]
		public void TestMethod2()
		{
			// Arrange
			double expected = 2;

			// Act

			// Assert
			double actual = Program.Average(2, 2);
			Assert.AreEqual(expected, actual, 0.001, "The method doesn't calculate the average.");
		}

		[TestMethod]
		public void TestMethod3()
		{
			// Arrange
			double expected = 4;

			// Act

			// Assert
			double actual = Program.Average(2, 2);
			Assert.AreNotEqual(expected, actual, 0.001, "The method doesn't calculate the average.");
		}
	}
}
