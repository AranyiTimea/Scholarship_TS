﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ex1
{
	public class Program
	{
		public static double Average(double a, double b)
		{
			return ((a + b) / 2);
		}

		public static void Main(string[] args)
		{
			Console.WriteLine(Average(2, 1));
		}
	}
}
