﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ex3_number_of_days;

namespace UnitTests_Ex3_2
{
	[TestClass]
	public class UnitTest1
	{
		[TestMethod]
		public void TestMethod1()
		{
			//arrange
			Utilities ut = new Utilities();
			DateTime past = new DateTime(2021, 07, 10);
			DateTime present = DateTime.Today;
			int expected = (present - past).Days;

			//act
			int actual = ut.NumberOfDays(past, present);

			//assert
			Assert.AreEqual(expected, actual); 
		}

		[TestMethod]
		public void TestMethod2()
		{
			//arrange
			Utilities ut = new Utilities();
			DateTime past = new DateTime(1021, 07, 10);
			DateTime present = DateTime.Today;
			int expected = (present - past).Days;

			//act
			int actual = ut.NumberOfDays(past, present);

			//assert
			Assert.AreEqual(expected, actual);
		}
	}
}
