﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ex2_generic_class;
using System.Collections.Generic;

namespace UnitTests_Ex3
{
	[TestClass]
	public class UnitTest1
	{
		[TestMethod]
		public void TestMinimum()
		{
			//arrange
			List<int> arr = new List<int> { 1, 2, 3 };
			Vector<int> vect = new Vector<int>(arr);
			int expected = 1;

			//act 
			int actual = vect.Min();

			//assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestMaximum()
		{
			//arrange
			List<int> arr = new List<int> { 1, 2, 3 };
			Vector<int> vect = new Vector<int>(arr);
			int expected = 3;

			//act 
			int actual = vect.Max();

			//assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestMaximum2()
		{
			//arrange
			List<int> arr = new List<int> { 1, 2, 3 };
			Vector<int> vect = new Vector<int>(arr);
			int expected = 1;

			//act 
			int actual = vect.Max();

			//assert
			Assert.AreNotEqual(expected, actual);
		}

		[TestMethod]
		public void TestCountGreaterThan()
		{
			//arrange
			List<int> arr = new List<int> { 1, 2, 3, 4 };
			Vector<int> vect = new Vector<int>(arr);
			int expected = 1;

			//act 
			int actual = vect.CountGreaterThan(3);

			//assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestContains()
		{
			//arrange
			List<int> arr = new List<int> { 1, 2, 3, 4 };
			Vector<int> vect = new Vector<int>(arr);
			bool expected = true;

			//act 
			bool actual = vect.Contains(3);

			//assert
			Assert.AreEqual(expected, actual);
		}


		[TestMethod]
		public void TestContains2()
		{
			//arrange
			List<int> arr = new List<int> { 1, 2, 3, 4 };
			Vector<int> vect = new Vector<int>(arr);
			bool expected = false;

			//act 
			bool actual = vect.Contains(5);

			//assert
			Assert.AreEqual(expected, actual);
		}
	}
}
