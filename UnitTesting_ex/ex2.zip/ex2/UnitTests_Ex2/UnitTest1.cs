﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ex6_pangram;

namespace UnitTests_Ex2
{
	[TestClass]
	public class UnitTest1
	{
		[TestMethod]
		public void TestMethod1()
		{
			// Arrange
			bool expected = true;
			Utilities ut = new Utilities();

			// Act
			bool actual = ut.PangramOrNot("The quick brown fox jumps over the lazy dog");

			// Assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestMethod2()
		{
			// Arrange
			bool expected = false;
			Utilities ut = new Utilities();

			// Act
			bool actual = ut.PangramOrNot("Ana are mere");

			// Assert
			Assert.AreEqual(expected, actual);
		}

		[TestMethod]
		public void TestMethod3()
		{
			// Arrange
			bool expected = true;
			Utilities ut = new Utilities();

			// Act
			bool actual = ut.PangramOrNot("Ana are mere");

			// Assert
			Assert.AreNotEqual(expected, actual);
		}
	}
}
